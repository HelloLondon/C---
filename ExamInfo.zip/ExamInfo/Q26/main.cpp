#include "sort.h"


int main() {


	int numSize;

	cin >> numSize;

	int *nums = new int[numSize];

	for (int i = 0; i < numSize; i++) {
		cin >> nums[i];
	}

	int result = findDuplicate(nums, numSize);

	cout << result;

	delete[] nums;

	return 0;
}