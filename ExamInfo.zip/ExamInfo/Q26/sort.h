#include <iostream>

using namespace std;

int findDuplicate(int* nums, int numsSize);
